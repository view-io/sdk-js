declare namespace ViewIO {
  /* third party alias */
  //type Storage = import("another-package").Storage // whatever
}
