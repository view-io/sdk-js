/**
 * Enum for DataCatalogType.
 * @enum {string}
 */
export const DataCatalogTypeEnum = Object.freeze({
  Lexi: 'Lexi',
});
