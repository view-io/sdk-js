const ApiVersionEnum = Object.freeze({
  Unknown: 'Unknown',
  V1_0: 'v1.0',
});

export default ApiVersionEnum;
