/**
 * Enum for SemanticCellType.
 * @enum {string}
 */
export const SemanticCellTypeEnum = Object.freeze({
  /** Text. */
  Text: 'Text',
});
