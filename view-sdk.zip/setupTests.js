jest.setTimeout(20000); // Set global timeout to 20 seconds
